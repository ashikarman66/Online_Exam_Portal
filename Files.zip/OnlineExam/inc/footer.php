 <style>
 .footeroption{background:#268e41;color:#fff;text-align:center;padding:20px;font-family: "Times New Roman", Times, serif;}
 </style>
 
</section>
<section class="footeroption">
		<h2><?php echo "Dept. of Computer Science & Engineering,GUB"; ?></h2>
	</section>
</div>
</body>
</html>