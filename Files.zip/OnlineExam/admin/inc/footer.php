 </section>
<section class="footeroption">
		<h2><?php echo "Dept. of Computer Science & Engineering, GUB"; ?></h2>
	</section>
</div>
</body>
</html>